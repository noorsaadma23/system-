CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    UserName VARCHAR(100),
    Role VARCHAR(50),
    Email VARCHAR(100)
);

CREATE TABLE Systems (
    SystemID INT PRIMARY KEY IDENTITY(1,1),
    SystemName VARCHAR(100),
    Description VARCHAR(255)
);

CREATE TABLE Operations (
    OperationID INT PRIMARY KEY IDENTITY(1,1),
    SystemID INT,
    OperationType VARCHAR(50),
    StartTime DATETIME,
    EndTime DATETIME,
    Status VARCHAR(20),
    FOREIGN KEY (SystemID) REFERENCES Systems(SystemID)
);

CREATE TABLE Errors (
    ErrorID INT PRIMARY KEY IDENTITY(1,1),
    OperationID INT,
    ErrorType VARCHAR(50),
    ErrorDescription TEXT,
    Timestamp DATETIME,
    FOREIGN KEY (OperationID) REFERENCES Operations(OperationID)
);

CREATE TABLE PerformanceMetrics (
    MetricID INT PRIMARY KEY IDENTITY(1,1),
    SystemID INT,
    MetricType VARCHAR(50),
    MetricValue FLOAT,
    Timestamp DATETIME,
    FOREIGN KEY (SystemID) REFERENCES Systems(SystemID)
);
