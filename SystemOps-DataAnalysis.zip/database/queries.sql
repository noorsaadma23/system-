-- عدد العمليات الناجحة والفاشلة لكل نظام
SELECT 
    s.SystemName,
    o.Status,
    COUNT(*) AS OperationCount
FROM 
    Operations o
JOIN 
    Systems s ON o.SystemID = s.SystemID
GROUP BY 
    s.SystemName, o.Status;

-- متوسط مدة العمليات حسب نوع العملية
SELECT
    OperationType,
    AVG(DATEDIFF(SECOND, StartTime, EndTime)) AS AvgDurationSeconds
FROM 
    Operations
GROUP BY 
    OperationType;

-- أكثر الأخطاء حدوثًا
SELECT
    ErrorType,
    COUNT(*) AS ErrorCount
FROM 
    Errors
GROUP BY 
    ErrorType
ORDER BY 
    ErrorCount DESC;
