INSERT INTO Users (UserName, Role, Email) VALUES
('Ali Ahmad', 'Admin', 'ali@example.com'),
('Sara Karim', 'Operator', 'sara@example.com');

INSERT INTO Systems (SystemName, Description) VALUES
('System A', 'Main database server'),
('System B', 'Backup server');

INSERT INTO Operations (SystemID, OperationType, StartTime, EndTime, Status) VALUES
(1, 'Backup', '2025-06-10 01:00', '2025-06-10 01:30', 'Success'),
(1, 'Update', '2025-06-11 03:00', '2025-06-11 03:45', 'Failed'),
(2, 'Backup', '2025-06-10 02:00', '2025-06-10 02:30', 'Success');

INSERT INTO Errors (OperationID, ErrorType, ErrorDescription, Timestamp) VALUES
(2, 'UpdateError', 'Failed to apply patch KB12345', '2025-06-11 03:15');

INSERT INTO PerformanceMetrics (SystemID, MetricType, MetricValue, Timestamp) VALUES
(1, 'CPU', 75.5, '2025-06-10 01:15'),
(2, 'CPU', 65.0, '2025-06-10 02:15');
